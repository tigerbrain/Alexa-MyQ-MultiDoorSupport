import requests
import os
import json
import time

APP_ID = "Vj8pQggXLhLy0WHahglCD4N1nAkkXQtGYpq2HrHD7H1nvmbT55KqtN6RSF4ILB%2Fi"
LOCALE = "en"

HOST_URI = "myqexternal.myqdevice.com"
LOGIN_ENDPOINT = "Membership/ValidateUserWithCulture"
DEVICE_LIST_ENDPOINT = "api/UserDeviceDetails"
DEVICE_SET_ENDPOINT = "Device/setDeviceAttribute"
DEVICE_STATUS_ENDPOINT = "Device/getDeviceAttribute"

INVONAME  = os.environ['inv_name']
USERNAME  = os.environ['username']
PASSWORD  = os.environ['password']
SKILL_ID  = os.environ['skill_id']
NO_OPEN   = os.environ['no_open']

myq_userid                  = ""
myq_security_token          = ""
myq_cached_login_response   = ""
myq_device_id               = []

def lambda_handler(event, context):

    failFunc = "N"

    if (INVONAME == ""):
        print("inv_name environment variable cannot be blank and needs to be set to your Alexa Skill's Invocation Name")
        failFunc = "Y"
        
    if (USERNAME == ""):
        print("username environment variable cannot be blank and needs to be set to your MyQ username")
        failFunc = "Y"
        
    if (PASSWORD == ""):
        print("password environment variable cannot be blank and needs to be set to your MyQ password")
        failFunc = "Y"

    if (SKILL_ID == ""):
        print("skill_id environment variable cannot be blank and needs to be set to your Alexa Skill's Application ID")
        failFunc = "Y"
        
    if (failFunc == "Y"):
        raise

    if event['session']['application']['applicationId'] != SKILL_ID:
        print "Invalid Application ID"
        raise
    else:
        # Not using sessions for now
        sessionAttributes = {}

        login()
        get_device_id()

        if event['session']['new']:
            onSessionStarted(event['request']['requestId'], event['session'])
        if event['request']['type'] == "LaunchRequest":
            speechlet = onLaunch(event['request'], event['session'])
            response = buildResponse(sessionAttributes, speechlet)
        elif event['request']['type'] == "IntentRequest":
            speechlet = onIntent(event['request'], event['session'])
            response = buildResponse(sessionAttributes, speechlet)
        elif event['request']['type'] == "SessionEndedRequest":
            speechlet = onSessionEnded(event['request'], event['session'])
            response = buildResponse(sessionAttributes, speechlet)

        # Return a response for speech output
        return(response)


def open(device):
    change_door_state(device, "open")

def close(device):
    change_door_state(device, "close")

def status(device):
    response = check_door_state(device)
    state = response["AttributeValue"]
    if state == "1":
        return "open"
    elif state == "2":
        return "closed"
    elif state == "3":
        return "stopped"
    elif state == "4":
        return "opening"
    elif state == "5":
        return "closing"
    elif state == "8":
        return "opening" # seen as documented as "moving"
    elif state == "9":
        return "open"
    else:
        return state + " is an unknown state for the door."

def login_uri():
    uri = "https://" + HOST_URI + "/" + LOGIN_ENDPOINT
    uri += "?appId=" + APP_ID
    uri += "&securityToken=null"
    uri += "&username=" + USERNAME
    uri += "&password=" + PASSWORD
    uri += "&culture=" + LOCALE

    return uri

def device_list_uri(security_token):
    uri = "https://" + HOST_URI + "/" + DEVICE_LIST_ENDPOINT
    uri += "?appId=" + APP_ID
    uri += "&securityToken=" + security_token

    return uri

def login():
    response = requests.get(login_uri()).json()

    global myq_userid
    global myq_security_token
    global myq_cached_login_response

    myq_userid = response["UserId"]
    myq_security_token = response["SecurityToken"]
    myq_cached_login_response = response

def change_door_state_uri():
    return "https://" + HOST_URI + "/" + DEVICE_SET_ENDPOINT

def change_door_state(device, command):
    open_close_state = 1 if command.lower() == "open" else 0

    body = {
        "AttributeName":"desireddoorstate",
        "DeviceId":myq_device_id[device],
        "ApplicationId":APP_ID,
        "AttributeValue":open_close_state,
        "SecurityToken":myq_security_token
    }
    
    print("Change Door State: " + str(myq_device_id[device]) + " to " + command)

    result = requests.put(change_door_state_uri(), data = body)

    return result.json()

def get_device_id():
      
    global myq_device_id
    
    myq_device_id = []

    devices = requests.get(device_list_uri(myq_security_token)).json()
    for dev in devices["Devices"]:
        if dev["MyQDeviceTypeName"] in ["VGDO", "GarageDoorOpener", "Garage Door Opener WGDO"]:
            myq_device_id.append(str(dev["DeviceId"]))
            print("MyQDeviceTypeName:" + str(dev["MyQDeviceTypeName"]))
            print("DeviceId:" + str(dev["DeviceId"]))
            print("Number of Devices:" + str(len(myq_device_id)))

def check_door_state_uri(device, command):
    uri = "https://" + HOST_URI + "/" + DEVICE_STATUS_ENDPOINT
    uri += "?appId=" + APP_ID
    uri += "&securityToken=" + myq_security_token
    uri += "&devId=" + myq_device_id[device]
    uri += "&name=" + command
    
    print("Check Door State: " + str(myq_device_id[device]))

    return uri

def check_door_state(device):
    uri = check_door_state_uri(device, "doorstate")
    return requests.get(uri).json()

    # Called when the session starts
def onSessionStarted(requestId, session):
    print("onSessionStarted requestId=" + requestId + ", sessionId=" + session['sessionId'])

# Called when the user launches the skill without specifying what they want.
def onLaunch(launchRequest, session):
    # Dispatch to your skill's launch.
    getWelcomeResponse()

# Called when the user specifies an intent for this skill.
def onIntent(intentRequest, session):
    intent = intentRequest['intent']
    intentName = intentRequest['intent']['name']

    # Dispatch to your skill's intent handlers
    if intentName == "StateIntent":
        return stateResponse(intent)
    elif intentName == "MoveIntent":
        return moveIntent(intent)
    elif intentName == "HelpIntent":
        return getWelcomeResponse()
    else:
        print "Invalid Intent (" + intentName + ")"
        raise

# Called when the user ends the session.
# Is not called when the skill returns shouldEndSession=true.
def onSessionEnded(sessionEndedRequest, session):
    # Add cleanup logic here
    print "Session ended"

def getWelcomeResponse():
    cardTitle = "Welcome"
    
    if (NO_OPEN.upper() == "Y") or (NO_OPEN.upper() == "YES"):
        speechOutput = "You can close your garage door by saying, ask " + INVONAME + " door one to close.  You can also check the state of your garage door by saying, ask " + INVONAME + " if door one is open"

        # If the user either does not reply to the welcome message or says something that is not
        # understood, they will be prompted again with this text.
        repromptText = "Ask me to close your garage door by saying, ask " + INVONAME + " door one to close, or ask me to check the state of your garage door by saying, ask " + INVONAME + " if door one is open"   
    else:
        speechOutput = "You can open your garage door by saying, ask " + INVONAME + " door one to open, or you can close your garage door by saying, ask " + INVONAME + " door one to close.  You can also check the state of your garage door by saying, ask " + INVONAME + " if door one is open"
        repromptText = "Ask me to open your garage door by saying, ask " + INVONAME + " door one to open, or ask me to close your garage door by saying, ask " + INVONAME + " door one to close.  You can also ask me to check the state of your garage door by saying, ask " + INVONAME + " if door one is open"
        
    shouldEndSession = True

    return (buildSpeechletResponse(cardTitle, speechOutput, repromptText, shouldEndSession))

def moveIntent(intent):
    # Ask garage door {1|2} to {open|close|shut|go up|go down}
    #     "intent": {
    #       "name": "StateIntent",
    #       "slots": {
    #         "doornum": {
    #           "name": "doornum",
    #           "value": "1"
    #         }    
    #         "doorstate": {
    #           "name": "doorstate",
    #           "value": "close"
    #         }
    #       }
    #     }
    
    if (NO_OPEN.upper() == "Y") or (NO_OPEN.upper() == "YES"):
        failureMsg  = "I didn't understand that. You can close your garage door by saying, ask " + INVONAME + " door one to close"
        repromptMsg = "Ask me to close your garage door by saying, ask " + INVONAME + " door one to close"
    else:
        failureMsg  = "I didn't understand that. You can open your garage door by saying, ask " + INVONAME + " door one to open, or you can close your garage door by saying, ask " + INVONAME + " door one to close"
        repromptMsg = "Ask me to open your garage door by saying, ask " + INVONAME + " door one to open, or ask me to close your garage door by saying, ask " + INVONAME + " door one to close"
    
    try:  
        doornum = intent['slots']['doornum']['value']
        
        if (doornum == "1"):
            device = 0
        elif (doornum == "2") or (doornum == "to") or (doornum == "too"):
            device = 1
        else:
            speechOutput = failureMsg
            cardTitle = "Try again" 
            repromptText = repromptMsg
            shouldEndSession = False
            return(buildSpeechletResponse(cardTitle, speechOutput, repromptText, shouldEndSession))        
                
        if (intent['slots']['doorstate']['value'] == "close") or (intent['slots']['doorstate']['value'] == "shut") or (intent['slots']['doorstate']['value'] == "down"):
            close(device)
            print("Closing...")
            speechOutput = "Ok, I'm closing garage door " + doornum
            cardTitle = "Closing your garage door"
        elif (intent['slots']['doorstate']['value'] == "open") or (intent['slots']['doorstate']['value'] == "up"):
            if (NO_OPEN.upper() == "Y") or (NO_OPEN.upper() == "YES"):
                speechOutput = failureMsg
                cardTitle = "Try again"
            else:
                open(device)
                print("Opening...")
                speechOutput = "Ok, I'm opening garage door " + doornum
                cardTitle = speechOutput
        else:
            speechOutput = failureMsg
            cardTitle = "Try again"
            
        repromptText = repromptMsg
        shouldEndSession = True

        return(buildSpeechletResponse(cardTitle, speechOutput, repromptText, shouldEndSession))
    
    except:
        speechOutput = failureMsg
        cardTitle = "Try again" 
        repromptText = repromptMsg
        shouldEndSession = False
        return(buildSpeechletResponse(cardTitle, speechOutput, repromptText, shouldEndSession))        
    

def stateResponse(intent):
    # Ask garage if door {1|2} is {open|up|close|closed|shut|down}
    #     "intent": {
    #       "name": "StateIntent",
    #       "slots": {
    #         "doornum": {
    #           "name": "doornum",
    #           "value": "1"
    #         }
    #         "doorstate": {
    #           "name": "doorstate",
    #           "value": "closed"
    #         }
    #       }
    #     }
    
    failureMsg  = "I didn't understand that. You can check the state of your garage door by saying ask " + INVONAME + " if door one is open"
    repromptMsg = "Ask me to check the state of your garage door by saying, ask " + INVONAME + " if door one is open"
    
    try:
        doornum = intent['slots']['doornum']['value']
        
        if (doornum == "1"):
            device = 0
        elif (doornum == "2") or (doornum == "to") or (doornum == "too"):
            device = 1
        else:
            speechOutput = failureMsg
            cardTitle = "Try again"
            repromptText = repromptMsg
            shouldEndSession = False
            return(buildSpeechletResponse(cardTitle, speechOutput, repromptText, shouldEndSession))    
            
        doorstate = status(device)    

        if (intent['slots']['doorstate']['value'] == "open") or (intent['slots']['doorstate']['value'] == "up"):
            if doorstate == "open":
                speechOutput = "Yes, garage door " + doornum + " is open"
                cardTitle = speechOutput
            elif doorstate == "closed":
                speechOutput = "No, garage door " + doornum + " is closed"
                cardTitle = speechOutput
            else:
                speechOutput = "Garage door " + doornum + " is " + doorstate
                cardTitle = speechOutput

        elif (intent['slots']['doorstate']['value'] == "close") or (intent['slots']['doorstate']['value'] == "closed") or (intent['slots']['doorstate']['value'] == "shut") or (intent['slots']['doorstate']['value'] == "down"):
            if doorstate == "closed":
                speechOutput = "Yes, garage door " + doornum + " is closed"
                cardTitle = speechOutput
            elif doorstate == "open":
                speechOutput = "No, garage door " + doornum + " is open"
                cardTitle = speechOutput
            else:
                speechOutput = "Garage door " + doornum + " is " + doorstate
                cardTitle = speechOutput

        else:
            speechOutput = failureMsg
            cardTitle = "Try again"

        repromptText = repromptMsg
        shouldEndSession = True

        return(buildSpeechletResponse(cardTitle, speechOutput, repromptText, shouldEndSession))
        
    except:
        speechOutput = failureMsg
        cardTitle = "Try again"
        repromptText = repromptMsg
        shouldEndSession = False
        return(buildSpeechletResponse(cardTitle, speechOutput, repromptText, shouldEndSession))


# --------------- Helpers that build all of the responses -----------------------
def buildSpeechletResponse(title, output, repromptText, shouldEndSession):
    return ({
        "outputSpeech": {
            "type": "PlainText",
            "text": output
        },
        "card": {
            "type": "Simple",
            "title": "MyQ - " + title,
            "content": "MyQ - " + output
        },
        "reprompt": {
            "outputSpeech": {
                "type": "PlainText",
                "text": repromptText
            }
        },
        "shouldEndSession": shouldEndSession
    })

def buildResponse(sessionAttributes, speechletResponse):
    return ({
        "version": "1.0",
        "sessionAttributes": sessionAttributes,
        "response": speechletResponse
    })
